package khushi.myapp.newcontactform


import android.content.Intent
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.EditText
import android.widget.ImageButton
import android.widget.Toast
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.Security;
import java.util.Properties;




class MainActivity : AppCompatActivity() {
    fun sendMessage(view: View){
        //Variable for edit text
        val editTextFirstName: EditText = findViewById<EditText>(R.id.editTextFirstName)
        val editTextLastName: EditText = findViewById<EditText>(R.id.editTextLastName)
        val editTextEmailAddress: EditText = findViewById<EditText>(R.id.editTextEmailAddress)
        val editTextSubject: EditText = findViewById<EditText>(R.id.editTextSubject)
        val editTextTextMultiLine: EditText = findViewById<EditText>(R.id.editTextTextMultiLine)

        //Log.i("details",editTextFirstName.text.toString())

        //creating/opening sql

        val mydatabase:SQLiteDatabase = this.openOrCreateDatabase("User", MODE_PRIVATE,null)
        //mydatabase.execSQL("DROP TABLE UserDetails")
        mydatabase.execSQL("DROP TABLE IF EXISTS user")
        mydatabase.execSQL("CREATE TABLE IF NOT  EXISTS User (Fname VARCHAR,Lname VARCHAR,Email VARCHAR,Sub VARCHAR,Mess VARCHAR)")
        mydatabase.execSQL("INSERT INTO User (Fname,Lname,Email,Sub,Mess) VALUES "+"("+ "'"+editTextFirstName.text.toString() + "'"+ "," + "'"+editTextLastName.text.toString() +"'" + "," + "'" + editTextEmailAddress.text.toString() + "'"+"," + "'" + editTextSubject.text.toString() +"'"+ ","+ "'" +editTextTextMultiLine.text.toString()+"'"+")")
        //Log.i("details",editTextFirstName.text.toString())
        //setting cursor
        val c:Cursor = mydatabase.rawQuery("SELECT * FROM User",null)
        c.moveToFirst()
        //getting all the user details from table

        var FnameIndex = c.getColumnIndex("Fname")
        var LnameIndex = c.getColumnIndex("Lname")
        var EmailIndex = c.getColumnIndex("Email")
        var SubIndex = c.getColumnIndex("Sub")
        var MessIndex = c.getColumnIndex("Mess")
        c.moveToFirst()
        do {
            Log.i("FnameIndex", c.getString(FnameIndex))
            Log.i("LnameIndex", c.getString(LnameIndex))
            Log.i("EmailIndex", c.getString(EmailIndex))
            Log.i("SubIndex", c.getString(SubIndex))
            Log.i("MessIndex", c.getString(MessIndex))
        }while(c.moveToNext())


    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        //setting all image buttons
        val imageButton: ImageButton = findViewById<ImageButton>(R.id.imageButton)
        val imageButton2: ImageButton = findViewById<ImageButton>(R.id.imageButton2)
        val imageButton3: ImageButton = findViewById<ImageButton>(R.id.imageButton3)
        val imageButton8: ImageButton = findViewById<ImageButton>(R.id.imageButton8)
        //setting intent
        val gourl = Intent(Intent.ACTION_VIEW,Uri.parse("https://www.facebook.com/khushi.singla.24"))
        val gourl2 = Intent(Intent.ACTION_VIEW,Uri.parse("https://twitter.com/khushisingla24"))
        val gourl3 = Intent(Intent.ACTION_VIEW,Uri.parse("https://www.youtube.com/channel/UCbFdjzj3lCverpoD422k1RQ"))
        val gourl8 = Intent(Intent.ACTION_VIEW,Uri.parse("https://www.instagram.com/_khushisingla/"))
        //facebook icon
        imageButton.setOnClickListener{
            Toast.makeText(
                applicationContext,
                "Opening Facebook",
                Toast.LENGTH_LONG
            ).show()
            startActivity(gourl)
        }
        //twitter icon
        imageButton2.setOnClickListener{
            Toast.makeText(
                applicationContext,
                "Opening twitter",
                Toast.LENGTH_LONG
            ).show()
            startActivity(gourl2)
        }
        //youtube icon
        imageButton3.setOnClickListener{
            Toast.makeText(
                applicationContext,
                "Opening youtube",
                Toast.LENGTH_LONG
            ).show()
            startActivity(gourl3)
        }
        //instagram icon
        imageButton8.setOnClickListener {
            Toast.makeText(
                applicationContext,
                "Opening Instagram",
                Toast.LENGTH_LONG
            ).show()
            startActivity(gourl8)
        }
    }
}